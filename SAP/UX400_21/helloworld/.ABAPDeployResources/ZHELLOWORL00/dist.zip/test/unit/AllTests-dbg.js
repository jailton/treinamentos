sap.ui.define([
	"student00sap.training./helloworld/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
